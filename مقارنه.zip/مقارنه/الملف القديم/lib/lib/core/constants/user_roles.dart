// ✅ تعريف الأدوار المختلفة للمستخدمين داخل النظام

class UserRoles {
  static const admin = 'admin';          // 👑 مالك النظام
  static const reception = 'reception';  // 🧑‍💼 موظف استقبال
  static const cleaner = 'cleaner';      // 🧹 موظف نظافة
  static const support = 'support';      // 🛠 الدعم الفني
}

// تقدر تستخدمها لاحقًا كالتالي:
// if (userRole == UserRoles.admin) { ... }
