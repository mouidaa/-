import 'package:flutter/material.dart';

class AppColors {
  static const Color primaryColor = Colors.deepPurple;
  static const Color accentColor = Colors.orange;
  static const Color backgroundColor = Colors.white;
  static const Color buttonColor = Colors.blue;
}
