// ✅ أسماء المسارات المستخدمة في التطبيق

class RouteNames {
  // 👤 المستخدمين
  static const login = '/login';
  static const register = '/register';

  // 🧾 الحجز والاستقبال
  static const home = '/home';
  static const booking = '/booking';
  static const roomDetails = '/roomDetails';
  static const serviceRequest = '/serviceRequest';
  static const bookingsList = '/bookingsList';
  static const filteredBookings = '/filteredBookings';

  // 👑 الإدارة
  static const adminDashboard = '/adminDashboard';
  static const adminServiceRequests = '/adminServiceRequests';
  static const bookingsReport = '/bookingsReport';
  static const missingItems = '/missingItems';

  // 🧹 موظف النظافة
  static const cleaningHome = '/cleaningHome';
  static const cleaningDetails = '/cleaningDetails'; // ✅ جديد
}
