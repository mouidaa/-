import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';

import 'core/constants/route_names.dart';
import 'core/constants/user_roles.dart';

import 'modules/reception_app/screens/home_screen.dart';
import 'modules/reception_app/screens/booking_screen.dart';
import 'modules/reception_app/screens/room_details_screen.dart';
import 'modules/reception_app/screens/service_request_screen.dart';
import 'modules/reception_app/screens/bookings_list_screen.dart';
import 'modules/reception_app/screens/filtered_bookings_screen.dart';

import 'modules/admin_app/screens/admin_dashboard_screen.dart';
import 'modules/admin_app/screens/admin_service_requests_screen.dart';
import 'modules/admin_app/screens/bookings_report_screen.dart';
import 'modules/admin_app/screens/missing_items_screen.dart';

import 'modules/cleaning_app/screens/cleaning_home_screen.dart';
import 'modules/cleaning_app/screens/cleaning_details_screen.dart';

import 'modules/auth/screens/login_screen.dart';
import 'modules/auth/screens/register_screen.dart';
import 'modules/auth/screens/role_selection_screen.dart';
import 'modules/guest/screens/guest_home_screen.dart';

import 'modules/auth/screens/role_protected_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'StayIn Hub',
      theme: ThemeData(
        primarySwatch: Colors.deepPurple,
      ),
      debugShowCheckedModeBanner: false,
      home: const RoleSelectionScreen(), // ✅ شاشة البداية

      routes: {
        // 👤 Auth
        RouteNames.login: (context) => const LoginScreen(),
        RouteNames.register: (context) => const RegisterScreen(),

        // 🧾 Reception
        RouteNames.home: (context) => const RoleProtectedScreen(
          allowedRoles: [UserRoles.reception],
          child: HomeScreen(),
        ),
        RouteNames.booking: (context) => const RoleProtectedScreen(
          allowedRoles: [UserRoles.reception],
          child: BookingScreen(),
        ),
        RouteNames.roomDetails: (context) => const RoleProtectedScreen(
          allowedRoles: [UserRoles.reception],
          child: RoomDetailsScreen(),
        ),
        RouteNames.serviceRequest: (context) => const RoleProtectedScreen(
          allowedRoles: [UserRoles.reception],
          child: ServiceRequestScreen(),
        ),
        RouteNames.bookingsList: (context) => const RoleProtectedScreen(
          allowedRoles: [UserRoles.reception],
          child: BookingsListScreen(),
        ),
        RouteNames.filteredBookings: (context) => const RoleProtectedScreen(
          allowedRoles: [UserRoles.reception],
          child: FilteredBookingsScreen(),
        ),

        // 👑 Admin
        RouteNames.adminDashboard: (context) => const RoleProtectedScreen(
          allowedRoles: [UserRoles.admin],
          child: AdminDashboardScreen(),
        ),
        RouteNames.adminServiceRequests: (context) => const RoleProtectedScreen(
          allowedRoles: [UserRoles.admin],
          child: AdminServiceRequestsScreen(),
        ),
        RouteNames.bookingsReport: (context) => const RoleProtectedScreen(
          allowedRoles: [UserRoles.admin],
          child: BookingsReportScreen(),
        ),
        RouteNames.missingItems: (context) => const RoleProtectedScreen(
          allowedRoles: [UserRoles.admin],
          child: MissingItemsScreen(),
        ),

        // 🧹 Cleaner
        RouteNames.cleaningHome: (context) => const RoleProtectedScreen(
          allowedRoles: [UserRoles.cleaner],
          child: CleaningHomeScreen(),
        ),

        // 👤 Guest
        RouteNames.guestHome: (context) => const GuestHomeScreen(),
      },

      // ✅ دعم التنقل مع arguments
      onGenerateRoute: (settings) {
        if (settings.name == RouteNames.cleaningDetails) {
          final roomNumber = settings.arguments as String;
          return MaterialPageRoute(
            builder: (context) => RoleProtectedScreen(
              allowedRoles: [UserRoles.cleaner],
              child: CleaningDetailsScreen(roomNumber: roomNumber),
            ),
          );
        }

        return null;
      },
    );
  }
}
