// ✅ شاشة تقارير الحجوزات - مع تصدير PDF و Excel

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:pdf/pdf.dart';
import 'package:printing/printing.dart';
import 'package:csv/csv.dart';
import 'dart:typed_data';

class BookingsReportScreen extends StatelessWidget {
  const BookingsReportScreen({super.key});

  Future<void> exportPDF(List<QueryDocumentSnapshot> data) async {
    final pdf = pw.Document();

    pdf.addPage(
      pw.MultiPage(
        build: (context) => [
          pw.Text('تقارير الحجوزات', style: pw.TextStyle(fontSize: 20)),
          pw.SizedBox(height: 20),
          ...data.map((doc) {
            final booking = doc.data() as Map<String, dynamic>;
            final name = booking['customerName'] ?? '';
            final phone = booking['phoneNumber'] ?? '';
            final room = booking['roomNumber'] ?? '';
            final method = booking['paymentMethod'] ?? '';
            final date = booking['checkInDate'] ?? '';
            final status = booking['status'] ?? '';
            return pw.Text('اسم: $name\nجوال: $phone\nغرفة: $room\nدفع: $method\nتاريخ: $date\nحالة: $status\n---');
          }),
        ],
      ),
    );

    await Printing.layoutPdf(
      onLayout: (PdfPageFormat format) async => pdf.save(),
    );
  }

  Future<void> exportCSV(List<QueryDocumentSnapshot> data) async {
    List<List<dynamic>> csvData = [
      ['الاسم', 'رقم الجوال', 'الغرفة', 'طريقة الدفع', 'تاريخ الدخول', 'الحالة'],
      ...data.map((doc) {
        final booking = doc.data() as Map<String, dynamic>;
        return [
          booking['customerName'] ?? '',
          booking['phoneNumber'] ?? '',
          booking['roomNumber'] ?? '',
          booking['paymentMethod'] ?? '',
          booking['checkInDate'] ?? '',
          booking['status'] ?? '',
        ];
      }),
    ];

    String csv = const ListToCsvConverter().convert(csvData);
    final bytes = Uint8List.fromList(csv.codeUnits);

    await Printing.sharePdf(bytes: bytes, filename: 'bookings_report.csv');
  }

  @override
  Widget build(BuildContext context) {
    final CollectionReference bookings = FirebaseFirestore.instance.collection('bookings');

    return Scaffold(
      appBar: AppBar(title: const Text('📄 تقارير الحجوزات')),
      body: StreamBuilder<QuerySnapshot>(
        stream: bookings.orderBy('checkInDate', descending: true).snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(child: Text('لا توجد حجوزات حالياً'));
          }

          final data = snapshot.data!.docs;

          return Column(
            children: [
              Expanded(
                child: ListView.builder(
                  itemCount: data.length,
                  itemBuilder: (context, index) {
                    final booking = data[index].data() as Map<String, dynamic>;
                    return Card(
                      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      child: ListTile(
                        title: Text('الاسم: ${booking['customerName'] ?? ''}'),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('رقم الجوال: ${booking['phoneNumber'] ?? ''}'),
                            Text('الغرفة: ${booking['roomNumber'] ?? ''}'),
                            Text('طريقة الدفع: ${booking['paymentMethod'] ?? ''}'),
                            Text('تاريخ الوصول: ${booking['checkInDate'] ?? ''}'),
                            Text('الحالة: ${booking['status'] ?? ''}'),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ElevatedButton.icon(
                    onPressed: () => exportPDF(data),
                    icon: const Icon(Icons.picture_as_pdf),
                    label: const Text('تصدير PDF'),
                  ),
                  ElevatedButton.icon(
                    onPressed: () => exportCSV(data),
                    icon: const Icon(Icons.table_chart),
                    label: const Text('تصدير Excel'),
                  ),
                ],
              ),
              const SizedBox(height: 16),
            ],
          );
        },
      ),
    );
  }
}
