import 'package:flutter/material.dart';
import 'package:stayin_hub_new/core/constants/route_names.dart';

class AdminServiceRequestsScreen extends StatelessWidget {
  const AdminServiceRequestsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('طلبات الخدمة (الإدارة)'),
      ),
      body: ListView.builder(
        itemCount: 5, // عدد الطلبات
        itemBuilder: (context, index) {
          return ListTile(
            title: Text('طلب الخدمة رقم ${index + 1}'),
            subtitle: const Text('تفاصيل الخدمة'),
            trailing: IconButton(
              icon: const Icon(Icons.check_circle),
              onPressed: () {
                // تحديث حالة الطلب
              },
            ),
          );
        },
      ),
    );
  }
}
