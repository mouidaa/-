import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import '../../../core/constants/route_names.dart';

class AdminDashboardScreen extends StatefulWidget {
  const AdminDashboardScreen({super.key});

  @override
  State<AdminDashboardScreen> createState() => _AdminDashboardScreenState();
}

class _AdminDashboardScreenState extends State<AdminDashboardScreen> {
  int totalToday = 0;
  int paidToday = 0;
  int leftToday = 0;

  Future<void> fetchStats() async {
    final now = DateTime.now();
    final startOfDay = DateTime(now.year, now.month, now.day);
    final snapshot = await FirebaseFirestore.instance.collection('bookings').get();

    int total = 0;
    int paid = 0;
    int left = 0;

    for (var doc in snapshot.docs) {
      final data = doc.data();
      final date = DateTime.tryParse(data['checkInDate'] ?? '') ?? DateTime(2000);
      final status = data['status'] ?? '';

      if (date.isAfter(startOfDay)) {
        total++;
        if (status == 'تم الدفع') paid++;
        if (status == 'مغادر') left++;
      }
    }

    setState(() {
      totalToday = total;
      paidToday = paid;
      leftToday = left;
    });
  }

  @override
  void initState() {
    super.initState();
    fetchStats();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('لوحة تحكم الإدارة')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('📊 إحصائيات اليوم (${DateFormat('yyyy-MM-dd').format(DateTime.now())}):',
                style: const TextStyle(fontSize: 18)),
            const SizedBox(height: 12),
            Text('📅 إجمالي الحجوزات: $totalToday'),
            Text('💳 المدفوع: $paidToday'),
            Text('🚪 المغادرين: $leftToday'),
            const SizedBox(height: 20),

            ElevatedButton(
              onPressed: fetchStats,
              child: const Text('🔄 تحديث الإحصائيات'),
            ),

            const SizedBox(height: 30),

            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, RouteNames.missingItems);
              },
              child: const Text('📋 تقارير النواقص'),
            ),

            const SizedBox(height: 16),

            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, RouteNames.bookingsReport);
              },
              child: const Text('📄 تقارير الحجوزات'),
            ),
          ],
        ),
      ),
    );
  }
}
