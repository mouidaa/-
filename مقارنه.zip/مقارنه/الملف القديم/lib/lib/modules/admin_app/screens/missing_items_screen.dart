// ✅ شاشة عرض تقارير النواقص مع تصدير PDF و Excel

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:csv/csv.dart';
import 'dart:io';
import 'dart:typed_data';

class MissingItemsScreen extends StatelessWidget {
  const MissingItemsScreen({super.key});

  Future<void> exportPDF(List<QueryDocumentSnapshot> data) async {
    final pdf = pw.Document();

    pdf.addPage(
      pw.MultiPage(
        build: (context) => [
          pw.Text('تقارير النواقص', style: pw.TextStyle(fontSize: 20)),
          pw.SizedBox(height: 20),
          ...data.map((doc) {
            final report = doc.data() as Map<String, dynamic>;
            final room = report['roomNumber'] ?? 'غير معروف';
            final items = List<String>.from(report['missingItems'] ?? []);
            final time = (report['timestamp'] as Timestamp).toDate();

            return pw.Container(
              margin: const pw.EdgeInsets.only(bottom: 10),
              child: pw.Text(
                'غرفة: $room\nنواقص: ${items.join(", ")}\nالتاريخ: ${DateFormat('yyyy-MM-dd – kk:mm').format(time)}\n',
              ),
            );
          }).toList(),
        ],
      ),
    );

    await Printing.layoutPdf(
      onLayout: (PdfPageFormat format) async => pdf.save(),
    );
  }

  Future<void> exportCSV(List<QueryDocumentSnapshot> data) async {
    List<List<dynamic>> csvData = [
      ['Room Number', 'Missing Items', 'Timestamp'],
      ...data.map((doc) {
        final report = doc.data() as Map<String, dynamic>;
        final room = report['roomNumber'] ?? 'غير معروف';
        final items = List<String>.from(report['missingItems'] ?? []).join(', ');
        final time = (report['timestamp'] as Timestamp).toDate();
        return [room, items, DateFormat('yyyy-MM-dd – kk:mm').format(time)];
      }),
    ];

    String csv = const ListToCsvConverter().convert(csvData);
    final bytes = Uint8List.fromList(csv.codeUnits);

    await Printing.sharePdf(bytes: bytes, filename: 'missing_items.csv');
  }

  @override
  Widget build(BuildContext context) {
    final CollectionReference reports = FirebaseFirestore.instance.collection('missing_items_reports');

    return Scaffold(
      appBar: AppBar(
        title: const Text('تقارير النواقص'),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: reports.orderBy('timestamp', descending: true).snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(child: Text('لا توجد تقارير حالياً'));
          }

          final data = snapshot.data!.docs;

          return Column(
            children: [
              Expanded(
                child: ListView.builder(
                  itemCount: data.length,
                  itemBuilder: (context, index) {
                    final doc = data[index];
                    final report = doc.data() as Map<String, dynamic>;
                    final room = report['roomNumber'] ?? 'غير معروف';
                    final items = List<String>.from(report['missingItems'] ?? []);
                    final time = (report['timestamp'] as Timestamp).toDate();

                    return Card(
                      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      child: ListTile(
                        title: Text('غرفة: $room'),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const SizedBox(height: 8),
                            Text('نواقص: ${items.join(", ")}'),
                            const SizedBox(height: 4),
                            Text('التاريخ: ${DateFormat('yyyy-MM-dd – kk:mm').format(time)}'),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ElevatedButton.icon(
                    onPressed: () => exportPDF(data),
                    icon: const Icon(Icons.picture_as_pdf),
                    label: const Text('تصدير PDF'),
                  ),
                  ElevatedButton.icon(
                    onPressed: () => exportCSV(data),
                    icon: const Icon(Icons.table_chart),
                    label: const Text('تصدير Excel'),
                  ),
                ],
              ),
              const SizedBox(height: 16),
            ],
          );
        },
      ),
    );
  }
}
