import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class SuperAdminSettingsScreen extends StatefulWidget {
  const SuperAdminSettingsScreen({super.key});

  @override
  State<SuperAdminSettingsScreen> createState() => _SuperAdminSettingsScreenState();
}

class _SuperAdminSettingsScreenState extends State<SuperAdminSettingsScreen> {
  final TextEditingController whatsappController = TextEditingController();
  final TextEditingController smsApiKeyController = TextEditingController();

  Future<void> loadSettings() async {
    final doc = await FirebaseFirestore.instance.collection('settings').doc('global').get();
    final data = doc.data();
    if (data != null) {
      whatsappController.text = data['whatsappNumber'] ?? '';
      smsApiKeyController.text = data['smsApiKey'] ?? '';
    }
  }

  Future<void> saveSettings() async {
    await FirebaseFirestore.instance.collection('settings').doc('global').set({
      'whatsappNumber': whatsappController.text.trim(),
      'smsApiKey': smsApiKeyController.text.trim(),
    });
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('✅ تم حفظ الإعدادات')));
  }

  @override
  void initState() {
    super.initState();
    loadSettings();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('إعدادات النظام')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: whatsappController,
              decoration: const InputDecoration(
                labelText: 'رقم واتساب المستخدم للإشعارات',
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: smsApiKeyController,
              decoration: const InputDecoration(
                labelText: 'مفتاح API لخدمة SMS',
              ),
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: saveSettings,
              child: const Text('💾 حفظ الإعدادات'),
            )
          ],
        ),
      ),
    );
  }
}
