import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';

class GuestFeedbackReportScreen extends StatelessWidget {
  const GuestFeedbackReportScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final feedbackRef = FirebaseFirestore.instance.collection('feedback').orderBy('timestamp', descending: true);

    return Scaffold(
      appBar: AppBar(title: const Text('تقرير تقييمات الضيوف')),
      body: StreamBuilder<QuerySnapshot>(
        stream: feedbackRef.snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(child: Text('لا توجد تقييمات بعد'));
          }

          final feedbackList = snapshot.data!.docs;

          return ListView.builder(
            itemCount: feedbackList.length,
            itemBuilder: (context, index) {
              final data = feedbackList[index].data() as Map<String, dynamic>;
              final phone = data['phoneNumber'] ?? '-';
              final rating = data['rating'] ?? 0;
              final note = data['note'] ?? '';
              final timestamp = (data['timestamp'] as Timestamp).toDate();

              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                child: ListTile(
                  title: Text('📞 $phone | ⭐ $rating'),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      if (note.isNotEmpty) Text('💬 $note'),
                      const SizedBox(height: 4),
                      Text('📅 ${DateFormat('yyyy-MM-dd – HH:mm').format(timestamp)}'),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
