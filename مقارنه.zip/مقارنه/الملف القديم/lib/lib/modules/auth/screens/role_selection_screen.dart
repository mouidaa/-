import 'package:flutter/material.dart';
import '../../auth/screens/login_screen.dart';
import '../../guest/screens/guest_home_screen.dart';

class RoleSelectionScreen extends StatelessWidget {
  const RoleSelectionScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('اختيار نوع الدخول')),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            ElevatedButton.icon(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const LoginScreen()),
                );
              },
              icon: const Icon(Icons.lock),
              label: const Text('دخول الموظفين / الإدارة'),
            ),
            const SizedBox(height: 24),
            ElevatedButton.icon(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const GuestHomeScreen()),
                );
              },
              icon: const Icon(Icons.person_outline),
              label: const Text('دخول كـ ضيف 👤'),
            ),
          ],
        ),
      ),
    );
  }
}
