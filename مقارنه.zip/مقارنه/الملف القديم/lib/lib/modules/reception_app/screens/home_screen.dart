import 'package:flutter/material.dart';
import 'package:stayin_hub_new/core/constants/route_names.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('الصفحة الرئيسية'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, RouteNames.booking);
              },
              child: const Text('الذهاب إلى صفحة الحجز'),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, RouteNames.bookingsList);
              },
              child: const Text('عرض الحجوزات'),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, RouteNames.filteredBookings);
              },
              child: const Text('فلترة الحجوزات'),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, RouteNames.adminDashboard);
              },
              child: const Text('لوحة تحكم الإدارة'),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, RouteNames.cleaningHome);
              },
              child: const Text('شاشة موظف التنظيف'), // ✅ الزر الجديد
            ),
          ],
        ),
      ),
    );
  }
}
