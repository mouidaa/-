import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../../core/constants/app_data.dart';
import '../../../core/constants/route_names.dart';
import '../../../services/api_service.dart';
import '../models/booking_model.dart';

class BookingScreen extends StatefulWidget {
  const BookingScreen({super.key});

  @override
  State<BookingScreen> createState() => _BookingScreenState();
}

class _BookingScreenState extends State<BookingScreen> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController phoneController = TextEditingController();
  final TextEditingController roomController = TextEditingController();
  DateTime? selectedDate;
  String selectedPayment = AppData.paymentMethods[0];
  final ApiService apiService = ApiService();

  Future<void> sendWhatsAppMessage(String phone, String message) async {
    final Uri url = Uri.parse("https://wa.me/$phone?text=${Uri.encodeFull(message)}");
    if (await canLaunchUrl(url)) {
      await launchUrl(url, mode: LaunchMode.externalApplication);
    } else {
      print('❌ لا يمكن فتح WhatsApp');
    }
  }

  Future<void> sendSMS(String phone, String message) async {
    final Uri url = Uri.parse("sms:$phone?body=${Uri.encodeFull(message)}");
    if (await canLaunchUrl(url)) {
      await launchUrl(url);
    } else {
      print('❌ لا يمكن إرسال SMS');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('إدارة الحجوزات'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('الحجز الجديد', style: TextStyle(fontSize: 22)),
              const SizedBox(height: 16),
              TextFormField(
                controller: nameController,
                decoration: const InputDecoration(labelText: 'اسم العميل'),
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: phoneController,
                decoration: const InputDecoration(labelText: 'رقم الجوال'),
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: roomController,
                decoration: const InputDecoration(labelText: 'رقم الغرفة'),
              ),
              const SizedBox(height: 16),
              InkWell(
                onTap: () async {
                  final DateTime? picked = await showDatePicker(
                    context: context,
                    initialDate: DateTime.now(),
                    firstDate: DateTime.now(),
                    lastDate: DateTime(2100),
                  );
                  if (picked != null) {
                    setState(() {
                      selectedDate = picked;
                    });
                  }
                },
                child: InputDecorator(
                  decoration: const InputDecoration(labelText: 'تاريخ الوصول'),
                  child: Text(
                    selectedDate == null
                        ? 'اختر التاريخ'
                        : DateFormat('yyyy-MM-dd').format(selectedDate!),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              DropdownButtonFormField<String>(
                value: selectedPayment,
                items: AppData.paymentMethods.map((method) {
                  return DropdownMenuItem(
                    value: method,
                    child: Text(method),
                  );
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    selectedPayment = value!;
                  });
                },
                decoration: const InputDecoration(labelText: 'وسيلة الدفع'),
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: () async {
                  if (nameController.text.isEmpty ||
                      phoneController.text.isEmpty ||
                      roomController.text.isEmpty ||
                      selectedDate == null) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('الرجاء تعبئة جميع الحقول')),
                    );
                    return;
                  }

                  final booking = BookingModel(
                    id: const Uuid().v4(),
                    customerName: nameController.text,
                    phoneNumber: phoneController.text,
                    checkInDate: selectedDate!,
                    paymentMethod: selectedPayment,
                    roomNumber: roomController.text,
                    status: 'قيد الانتظار',
                  );

                  await apiService.addBooking(booking);

                  await apiService.createCleaningRequest(
                    bookingId: booking.id,
                    roomNumber: booking.roomNumber,
                  );

                  await sendWhatsAppMessage(
                      booking.phoneNumber,
                      'مرحباً ${booking.customerName}، تم تسجيل حجزك في فندقنا. رقم الغرفة: ${booking.roomNumber}. نراك قريباً!'
                  );

                  await sendSMS(
                    booking.phoneNumber,
                    'أهلاً ${booking.customerName} 👋\nتم تأكيد حجزك لدينا. رقم الغرفة: ${booking.roomNumber}، نتشرف بخدمتك.',
                  );

                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('✅ تم تسجيل الحجز بنجاح')),
                  );

                  nameController.clear();
                  phoneController.clear();
                  roomController.clear();
                  setState(() {
                    selectedDate = null;
                    selectedPayment = AppData.paymentMethods[0];
                  });
                },
                child: const Text('إتمام الحجز'),
              ),
              const SizedBox(height: 12),
              ElevatedButton(
                onPressed: () {
                  Navigator.pushNamed(context, RouteNames.bookingsList);
                },
                child: const Text('📋 عرض جميع الحجوزات'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}