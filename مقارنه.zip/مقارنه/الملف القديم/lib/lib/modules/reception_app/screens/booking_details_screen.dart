import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:stayin_hub_new/core/constants/route_names.dart';
import '../models/booking_model.dart';
import 'package:printing/printing.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:esc_pos_utils_plus/esc_pos_utils_plus.dart';
import 'package:blue_print_pos/blue_print_pos.dart';

class BookingDetailsScreen extends StatefulWidget {
  final BookingModel booking;

  const BookingDetailsScreen({super.key, required this.booking});

  @override
  State<BookingDetailsScreen> createState() => _BookingDetailsScreenState();
}

class _BookingDetailsScreenState extends State<BookingDetailsScreen> {
  final ApiService apiService = ApiService();
  late TextEditingController roomController;
  late String selectedPayment;
  final BluePrintPos bluePrintPos = BluePrintPos();

  @override
  void initState() {
    super.initState();
    roomController = TextEditingController(text: widget.booking.roomNumber);
    selectedPayment = widget.booking.paymentMethod;
  }

  @override
  void dispose() {
    roomController.dispose();
    super.dispose();
  }

  void updateBooking() async {
    final updatedBooking = BookingModel(
      id: widget.booking.id,
      customerName: widget.booking.customerName,
      checkInDate: widget.booking.checkInDate,
      paymentMethod: selectedPayment,
      roomNumber: roomController.text,
      status: widget.booking.status,
    );

    await apiService.updateBooking(updatedBooking);

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('✅ تم تحديث الحجز')),
    );

    Navigator.pop(context);
  }

  void deleteBooking() async {
    await apiService.deleteBooking(widget.booking.id);

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('🗑️ تم إلغاء الحجز')),
    );

    Navigator.pop(context);
  }

  void printInvoicePDF() async {
    final pdf = pw.Document();
    pdf.addPage(
      pw.Page(
        build: (pw.Context context) {
          return pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Text('فاتورة الحجز', style: pw.TextStyle(fontSize: 24)),
              pw.SizedBox(height: 20),
              pw.Text('العميل: ${widget.booking.customerName}'),
              pw.Text('الغرفة: ${widget.booking.roomNumber}'),
              pw.Text('الدفع: ${widget.booking.paymentMethod}'),
              pw.Text('الحالة: ${widget.booking.status}'),
              pw.Text('الوصول: ${DateFormat('yyyy-MM-dd').format(widget.booking.checkInDate)}'),
            ],
          );
        },
      ),
    );
    await Printing.layoutPdf(onLayout: (format) => pdf.save());
  }

  void printInvoiceBluetooth() async {
    final profile = await CapabilityProfile.load();
    final generator = Generator(PaperSize.mm58, profile);
    final List<int> bytes = [];

    bytes += generator.text('فاتورة الحجز', styles: const PosStyles(align: PosAlign.center, bold: true));
    bytes += generator.text('العميل: ${widget.booking.customerName}');
    bytes += generator.text('الغرفة: ${widget.booking.roomNumber}');
    bytes += generator.text('الدفع: ${widget.booking.paymentMethod}');
    bytes += generator.text('الحالة: ${widget.booking.status}');
    bytes += generator.text('الوصول: ${DateFormat('yyyy-MM-dd').format(widget.booking.checkInDate)}');
    bytes += generator.feed(2);
    bytes += generator.cut();

    await bluePrintPos.printBytes(bytes);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('تفاصيل الحجز'),
        actions: [
          IconButton(
            icon: const Icon(Icons.delete),
            onPressed: deleteBooking,
          )
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('اسم العميل: ${widget.booking.customerName}', style: const TextStyle(fontSize: 18)),
            const SizedBox(height: 10),
            Text('تاريخ الوصول: ${DateFormat('yyyy-MM-dd').format(widget.booking.checkInDate)}'),
            const SizedBox(height: 10),
            Text('الحالة الحالية: ${widget.booking.status}'),
            const SizedBox(height: 20),

            TextFormField(
              controller: roomController,
              decoration: const InputDecoration(labelText: 'رقم الغرفة'),
            ),
            const SizedBox(height: 16),

            DropdownButtonFormField<String>(
              value: selectedPayment,
              items: ['كاش', 'STC Pay', 'مدى', 'Apple Pay'].map((method) {
                return DropdownMenuItem(
                  value: method,
                  child: Text(method),
                );
              }).toList(),
              onChanged: (value) {
                setState(() {
                  selectedPayment = value!;
                });
              },
              decoration: const InputDecoration(labelText: 'وسيلة الدفع'),
            ),
            const SizedBox(height: 24),

            ElevatedButton(
              onPressed: updateBooking,
              child: const Text('تحديث البيانات'),
            ),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: printInvoicePDF,
              child: const Text('🖨️ طباعة فاتورة PDF'),
            ),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: printInvoiceBluetooth,
              child: const Text('🔵 طباعة بلوتوث'),
            ),
          ],
        ),
      ),
    );
  }
}