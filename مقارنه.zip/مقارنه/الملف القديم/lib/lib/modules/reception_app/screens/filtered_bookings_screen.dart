// ✅ شاشة فلترة الحجوزات حسب الحالة

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../../services/api_service.dart';
import '../models/booking_model.dart';
import 'booking_details_screen.dart';

class FilteredBookingsScreen extends StatefulWidget {
  const FilteredBookingsScreen({super.key});

  @override
  State<FilteredBookingsScreen> createState() => _FilteredBookingsScreenState();
}

class _FilteredBookingsScreenState extends State<FilteredBookingsScreen> {
  final ApiService apiService = ApiService();
  late Future<List<BookingModel>> bookingsFuture;
  String selectedStatus = 'الكل';

  @override
  void initState() {
    super.initState();
    bookingsFuture = apiService.fetchBookings();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('فلترة الحجوزات'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: DropdownButtonFormField<String>(
              value: selectedStatus,
              decoration: const InputDecoration(labelText: 'الحالة'),
              items: ['الكل', 'قيد الانتظار', 'تم الدفع', 'مغادر'].map((status) {
                return DropdownMenuItem(
                  value: status,
                  child: Text(status),
                );
              }).toList(),
              onChanged: (value) {
                setState(() {
                  selectedStatus = value!;
                });
              },
            ),
          ),
          Expanded(
            child: FutureBuilder<List<BookingModel>>(
              future: bookingsFuture,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                } else if (snapshot.hasError) {
                  return const Center(child: Text('حدث خطأ أثناء التحميل'));
                } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                  return const Center(child: Text('لا توجد حجوزات'));
                }

                final filtered = selectedStatus == 'الكل'
                    ? snapshot.data!
                    : snapshot.data!.where((b) => b.status == selectedStatus).toList();

                return ListView.builder(
                  itemCount: filtered.length,
                  itemBuilder: (context, index) {
                    final booking = filtered[index];
                    return Card(
                      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      child: ListTile(
                        title: Text('العميل: ${booking.customerName}'),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('الغرفة: ${booking.roomNumber}'),
                            Text('الدفع: ${booking.paymentMethod}'),
                            Text('الحالة: ${booking.status}'),
                            Text('الوصول: ${DateFormat('yyyy-MM-dd').format(booking.checkInDate)}'),
                          ],
                        ),
                        trailing: const Icon(Icons.arrow_forward_ios),
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => BookingDetailsScreen(booking: booking),
                            ),
                          );
                        },
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
