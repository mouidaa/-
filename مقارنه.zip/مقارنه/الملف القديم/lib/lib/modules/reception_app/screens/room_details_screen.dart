import 'package:flutter/material.dart';
import 'package:stayin_hub_new/core/constants/route_names.dart';

class RoomDetailsScreen extends StatelessWidget {
  const RoomDetailsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('تفاصيل الغرفة'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('غرفة 101', style: TextStyle(fontSize: 22)),
            const SizedBox(height: 16),
            const Text('الحالة: مشغولة', style: TextStyle(fontSize: 18)),
            const SizedBox(height: 24),

            // ✅ زر لتغيير الحالة
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, RouteNames.cleaningHome);
              },
              child: const Text('🔄 إرسال للتنظيف'),
            ),

            const SizedBox(height: 12),

            // ✅ زر للرجوع للخلف
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('⬅️ رجوع'),
            ),
          ],
        ),
      ),
    );
  }
}
