import 'package:flutter/material.dart';
import 'package:stayin_hub_new/core/constants/route_names.dart';

class ServiceRequestScreen extends StatelessWidget {
  const ServiceRequestScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("طلب خدمة"),
      ),
      body: Center(
        child: ElevatedButton(
          onPressed: () {
            Navigator.pushNamed(context, RouteNames.adminServiceRequests); // مثال
          },
          child: const Text('عرض الطلبات السابقة'),
        ),
      ),
    );
  }
}
