class BookingModel {
  final String id;
  final String customerName;
  final String roomNumber;
  final String paymentMethod;
  final String status;
  final DateTime checkInDate;

  BookingModel({
    required this.id,
    required this.customerName,
    required this.roomNumber,
    required this.paymentMethod,
    required this.status,
    required this.checkInDate,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'customerName': customerName,
      'roomNumber': roomNumber,
      'paymentMethod': paymentMethod,
      'status': status,
      'checkInDate': checkInDate.toIso8601String(),
    };
  }

  factory BookingModel.fromMap(Map<String, dynamic> map) {
    return BookingModel(
      id: map['id'] ?? '',
      customerName: map['customerName'] ?? '',
      roomNumber: map['roomNumber'] ?? '',
      paymentMethod: map['paymentMethod'] ?? '',
      status: map['status'] ?? '',
      checkInDate: DateTime.parse(map['checkInDate']),
    );
  }
}
