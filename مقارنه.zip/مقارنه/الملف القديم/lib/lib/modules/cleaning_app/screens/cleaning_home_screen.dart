import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:stayin_hub_new/core/constants/route_names.dart';

class CleaningHomeScreen extends StatefulWidget {
  const CleaningHomeScreen({super.key});

  @override
  State<CleaningHomeScreen> createState() => _CleaningHomeScreenState();
}

class _CleaningHomeScreenState extends State<CleaningHomeScreen> {
  final CollectionReference cleaningCollection =
  FirebaseFirestore.instance.collection('cleaning_requests');

  Future<void> markAsCleaned(String bookingId) async {
    await cleaningCollection.doc(bookingId).update({'status': 'تم التنظيف'});
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('✅ تم تأكيد التنظيف')),
    );
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('مهام التنظيف'),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: cleaningCollection
            .where('status', isEqualTo: 'قيد التنظيف')
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(child: Text('لا توجد مهام تنظيف حالياً'));
          }

          final docs = snapshot.data!.docs;

          return ListView.builder(
            itemCount: docs.length,
            itemBuilder: (context, index) {
              final data = docs[index].data() as Map<String, dynamic>;
              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: ListTile(
                  title: Text('الغرفة: ${data['roomNumber']}'),
                  subtitle: Text('معرّف الحجز: ${data['bookingId']}'),
                  onTap: () {
                    Navigator.pushNamed(
                      context,
                      RouteNames.cleaningDetails,
                      arguments: data['roomNumber'],
                    );
                  },
                  trailing: ElevatedButton(
                    onPressed: () => markAsCleaned(data['bookingId']),
                    child: const Text('تم التنظيف'),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
