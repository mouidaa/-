import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';

class GuestBookingLookupScreen extends StatefulWidget {
  const GuestBookingLookupScreen({super.key});

  @override
  State<GuestBookingLookupScreen> createState() => _GuestBookingLookupScreenState();
}

class _GuestBookingLookupScreenState extends State<GuestBookingLookupScreen> {
  final TextEditingController phoneController = TextEditingController();
  Map<String, dynamic>? bookingData;
  bool isLoading = false;

  Future<void> fetchBooking() async {
    setState(() {
      isLoading = true;
      bookingData = null;
    });

    final query = await FirebaseFirestore.instance
        .collection('bookings')
        .where('phoneNumber', isEqualTo: phoneController.text.trim())
        .limit(1)
        .get();

    if (query.docs.isNotEmpty) {
      setState(() {
        bookingData = query.docs.first.data();
      });
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('❌ لم يتم العثور على حجز بهذا الرقم')),
      );
    }

    setState(() => isLoading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('استعراض الحجز للضيف')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: phoneController,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(labelText: 'رقم الجوال المرتبط بالحجز'),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: isLoading ? null : fetchBooking,
              child: const Text('🔍 عرض تفاصيل الحجز'),
            ),
            const SizedBox(height: 24),
            if (bookingData != null) ...[
              const Text('📋 تفاصيل الحجز:', style: TextStyle(fontSize: 18)),
              const SizedBox(height: 12),
              Text('👤 الاسم: ${bookingData!['customerName'] ?? 'غير معروف'}'),
              Text('📞 الجوال: ${bookingData!['phoneNumber'] ?? '-'}'),
              Text('🏨 الغرفة: ${bookingData!['roomNumber'] ?? '-'}'),
              Text('🕓 التاريخ: ${bookingData!['checkInDate'] != null ? DateFormat('yyyy-MM-dd').format(DateTime.parse(bookingData!['checkInDate'])) : '-'}'),
              Text('💳 الدفع: ${bookingData!['paymentMethod'] ?? '-'}'),
              Text('📌 الحالة: ${bookingData!['status'] ?? '-'}'),
            ]
          ],
        ),
      ),
    );
  }
}
