class BookingModel {
  final String id;
  final String customerName;
  final String phoneNumber; // ✅ جديد
  final DateTime checkInDate;
  final String paymentMethod;
  final String roomNumber;
  final String status;

  BookingModel({
    required this.id,
    required this.customerName,
    required this.phoneNumber, // ✅ جديد
    required this.checkInDate,
    required this.paymentMethod,
    required this.roomNumber,
    required this.status,
  });

  // ✅ لتحويل الكائن إلى خريطة (Map) لحفظه في Firebase
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'customerName': customerName,
      'phoneNumber': phoneNumber, // ✅ جديد
      'checkInDate': checkInDate.toIso8601String(),
      'paymentMethod': paymentMethod,
      'roomNumber': roomNumber,
      'status': status,
    };
  }

  // ✅ لتحويل البيانات من Firebase إلى كائن BookingModel
  factory BookingModel.fromMap(Map<String, dynamic> map) {
    return BookingModel(
      id: map['id'] ?? '',
      customerName: map['customerName'] ?? '',
      phoneNumber: map['phoneNumber'] ?? '', // ✅ جديد
      checkInDate: DateTime.parse(map['checkInDate']),
      paymentMethod: map['paymentMethod'] ?? '',
      roomNumber: map['roomNumber'] ?? '',
      status: map['status'] ?? '',
    );
  }
}
