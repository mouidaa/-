// lib/firebase_options.dart

class DefaultFirebaseOptions {
  static const currentPlatform = null;
}
