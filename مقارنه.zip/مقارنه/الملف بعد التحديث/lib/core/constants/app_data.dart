class AppData {
  static const List<String> roomStatuses = [
    'متاحة',
    'مشغولة',
    'تحتاج تنظيف',
  ];

  static const List<String> paymentMethods = [
    'كاش',
    'STC Pay',
    'مدى',
    'Apple Pay',
  ];
}
