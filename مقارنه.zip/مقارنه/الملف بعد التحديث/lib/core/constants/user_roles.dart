class UserRoles {
  static const String reception = 'reception';
  static const String admin = 'admin';
  static const String cleaner = 'cleaner';
  static const String superAdmin = 'super_admin';
  static const String guest = 'guest';
}
